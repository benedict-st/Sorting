import users from "./fake.api/user.api";
import professions from "./fake.api/professional.api";
const API = {
    users,
    professions
};
export default API;
